# Resume
一个简洁的橙色调个人简介。

## 使用方法
1. Star 本项目
2. Clone 本项目
3. 按照自己的需求修改内容和风格即可

## 项目故事
这是一个以个人需求演变而来的玩意，其实很早就做好了，只是一直都没有发出来。而在近期，我重新修改了一部分的结构和样式，于是现在就开源啦！

## 开源协议
本项目采用 MIT 开源协议进行授权，并在其基础上须保留原作者的版权注释（CSS、JS 等文件），当然能在页尾写上项目原地址就是最好的啦~

原创不易！如果喜欢本项目，请 Star 它以示对我的支持~

同时欢迎前往 [我的博客](https://paugram.com/about.html#donate) 为我提供赞助，谢谢您！

## 使用的开源项目
 - [Kico Style](https://github.com/Dreamer-Paul/Kico-Style)
 - [Font Awesome](https://github.com/FortAwesome/Font-Awesome)