# **前言**

https://github.com/dmego/home.github.io home.github.io<br/>
https://github.com/Dreamer-Paul/Resume 一个简洁的橙色调个人简介 <br/>
https://github.com/CitronsBlog/Introduced Introduced<br/>

<font color=red face="微软雅黑">感谢上述大佬的开源代码。（我不生产代码，我只是代码的搬运工emmm）</font>

<a href="https://sx4.oyyandwjw.cn/" target="_blank">项目演示</a><---点这里<br/>

[个人博客](https://www.oyyandwjw.cn)<---点这里

本项目主要为实训。

| 实验目的 | 通过该实验使学生能综合运用所学的HTML、CSS与JS等前端知识。 |
| -------- | --------------------------------------------------------- |
|          |                                                           |

| 实验内容（实验原理、运用的理论知识、算法、程序、步骤和方法）***\*要求：\****（1）结构要求：主页和二级页面美观，至少2段以上文字介绍自己，至少3个二级页面（主页超链接进入），至少3张图片，有背景音乐。（2）内容要求：个人自序、个人爱好、个人成绩、收藏夹（网上好的文章或诗词等的链接）等部分。（3）技术要求：网页美观，内容丰富，浏览方便，界面友好，使用的HTML标签/样式及其JavaScript特效。 |
| ------------------------------------------------------------ |
|                                                              |

实现了主页+自序+爱好+成绩+收藏，感兴趣的人请点个赞噢~# Personal-home-page

